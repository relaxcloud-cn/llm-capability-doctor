curl --request POST 'https://ai.gov110.cn/llm_v2/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${MODEL_API_KEY}" \
  --data-raw '{"max_tokens":2048,"messages":[{"content":"这是并发请求测试。请原样返回以下 JSON，不增加字段或解释：{\"ok\":true,\"probe_id\":\"8e8afb0aacbc4d5e8b6336aff3f3b01e\"}","role":"user"}],"model":"cybersec-1.0","stream":false}'
