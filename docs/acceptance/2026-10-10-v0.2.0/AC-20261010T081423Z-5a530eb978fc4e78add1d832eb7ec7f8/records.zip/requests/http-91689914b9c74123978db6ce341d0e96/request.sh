curl --request POST 'https://ai.gov110.cn/llm_v2/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${MODEL_API_KEY}" \
  --data-raw '{"max_tokens":2048,"messages":[{"content":"这是模型连接检查，请用中文简短回复。","role":"user"},{"annotations":null,"audio":null,"content":"连接正常。我在，请说。","function_call":null,"reasoning":"好的，用户发来一个简单的连接检查请求，要求用中文简短回复。这个需求很明确，就是确认系统正常运作。\n\n直接回复确认连接正常，并表明状态和可提供帮助的意愿，这样既简洁又符合用户要求。无需额外信息，保持回复轻量即可。","refusal":null,"role":"assistant"},{"content":"请继续用中文简短回复连接确认。","role":"user"}],"model":"cybersec-1.0","stream":true}'
