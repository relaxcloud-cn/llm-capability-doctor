curl --request POST 'https://ai.gov110.cn/llm_v2/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${MODEL_API_KEY}" \
  --data-raw '{"max_tokens":2048,"messages":[{"content":"这是模型连接检查，请用中文简短回复。","role":"user"},{"annotations":null,"audio":null,"content":"收到，模型连接正常。","function_call":null,"reasoning":"我们要求用中文简短回复。直接回复即可。","refusal":null,"role":"assistant"},{"content":"请继续用中文简短回复连接确认。","role":"user"}],"model":"cybersec-1.0","stream":true}'
