curl --request POST 'https://ai.gov110.cn/llm_v2/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${MODEL_API_KEY}" \
  --data-raw '{"max_tokens":2048,"messages":[{"content":"这是模型连接检查，请用中文简短回复。","role":"user"},{"annotations":null,"audio":null,"content":"连接正常，中文回复测试成功。","function_call":null,"reasoning":"好的，用户只是需要确认连接状态，要求简短回复。直接用中文确认连接正常即可，不需要额外解释或展开。回复内容就一两句话，保持简洁明了，符合用户指令。","refusal":null,"role":"assistant"},{"content":"请继续用中文简短回复连接确认。","role":"user"}],"model":"cybersec-1.0","stream":true}'
