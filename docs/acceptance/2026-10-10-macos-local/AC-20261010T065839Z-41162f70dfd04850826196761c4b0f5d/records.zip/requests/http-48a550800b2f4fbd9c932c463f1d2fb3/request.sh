curl --request POST 'https://ai.gov110.cn/llm_v2/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${MODEL_API_KEY}" \
  --data-raw '{"max_tokens":2048,"messages":[{"content":"这是模型连接检查，请用中文简短回复。","role":"user"},{"annotations":null,"audio":null,"content":"连接正常，请问有什么可以帮您？","function_call":null,"reasoning":"好的，用户发起了一个模型连接检查，要求用中文简短回复。这是一个非常简单的请求，核心是确认连接正常并回应用户的指令。直接给出一个肯定、简洁的回应即可，不需要任何额外解释或扩展。想到了用“连接正常”来确认状态，然后用“请问有什么可以帮您？”来承接后续对话并保持服务性。这样既完成了检查，又自然转入下一步互动。","refusal":null,"role":"assistant"},{"content":"请继续用中文简短回复连接确认。","role":"user"}],"model":"cybersec-1.0","stream":true}'
